/*2.4: Modify Lab assignment 2.3 to accept phone number of a person.
Create a newmethod to implement the same and
 also define method for displaying persondetails.*/

public class MainPersonDetails 
{
	
		 String firstName;
		 String lastName;
		 char gender;
		 int phoneNum;
		
		public MainPersonDetails()
		{
		}
		
		public String getFirstName()
		{
			return firstName;
		}
		
		public void setFirstName(String firstName)
		{
			this.firstName= firstName;
		}
		
		public String getLastName()
		{
			return lastName;
		}
		
		public void setLastName(String lastName)
		{
			this.lastName= lastName;
		}
		
		public char getGender()
		{
			return gender;
		}
		
		public void setGender(char gender)
		{
			this.gender= gender;
		}
		
		public int getPhoneNum()
		{
			return phoneNum;
		}
		
		public void setPhoneNum(int phoneNum)
		{
			this.phoneNum= phoneNum;
		}
	}

