import java.util.Scanner;



public class TestMainPersonDetails {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		MainPersonDetails s1 = new MainPersonDetails();
		s1.setFirstName("dhruvi");
		s1.setLastName("doshi");
		s1.setGender('M');
		System.out.println("Enter phone num");
		int phn = sc.nextInt();
		s1.setPhoneNum(phn);
		System.out.println(" student first name : " +s1.getFirstName()+" Student last name : " + s1.getLastName()+" Gender : " +s1.getGender()+" salary : " +s1.getPhoneNum());
		
		MainPersonDetails s2 = new MainPersonDetails();
		s2.setFirstName("darsh");
		s2.setLastName("doshi");
		s2.setGender('F');
		System.out.println("Enter phone num");
		int phn2 = sc.nextInt();
		s2.setPhoneNum(phn2);
		System.out.println(" student first name : " +s2.getFirstName()+" Student last name : " + s2.getLastName()+" Gender : " +s2.getGender()+" salary : " +s2.getPhoneNum());
		
		MainPersonDetails s3 = new MainPersonDetails();
		System.out.println(" student first name : " +s3.getFirstName()+" Student last name : " + s3.getLastName()+" Gender : " +s3.getGender()+" salary : " +s3.getPhoneNum());	
	sc.close();
}
}
