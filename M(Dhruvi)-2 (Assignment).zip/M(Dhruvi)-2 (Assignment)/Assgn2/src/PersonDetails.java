//2.1 Write a java program to print person details in the format as shown below:

public class PersonDetails
{
	public static void main(String aa[])
	{
		
			System.out.println("Person Details :");
			System.out.println("----------------");
			System.out.println(	"First Name: Divya \nLast Name: Bharathi \nGender: F \nAge: 20 Weight: 85.55");
		
	}
}


