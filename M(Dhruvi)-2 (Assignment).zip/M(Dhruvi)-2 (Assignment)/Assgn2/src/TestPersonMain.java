
public class TestPersonMain {
	public static void main(String args[]){
		PersonMain s1 = new PersonMain();
		s1.setFirstName("dhruvi");
		s1.setLastName("doshi");
		s1.setGender('M');
	
		PersonMain s2 = new PersonMain();
		s2.setFirstName("darsh");
		s2.setLastName("doshi");
		s2.setGender('F');
		
		PersonMain s3 = new PersonMain();
		
		System.out.println(" student first name : " +s1.getFirstName()+" Student last name : " + s1.getLastName()+" Gender : " +s1.getGender());
		System.out.println(" student first name : " +s2.getFirstName()+" Student last name : " + s2.getLastName()+" Gender : " +s2.getGender());
		System.out.println(" student first name : " +s3.getFirstName()+" Student last name : " + s3.getLastName()+" Gender : " +s3.getGender());
		
	}

}
