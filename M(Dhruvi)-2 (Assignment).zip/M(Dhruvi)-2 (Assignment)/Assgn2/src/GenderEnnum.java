/*2.5: Modify the above program, to accept only �M� or �F� as gender field values.
Use Enumeration for implementing the same.*/
enum Gender
{
	M,F;
}

public class GenderEnnum 
{
		 String firstName;
		 String lastName;
		 char gender;
		 int phoneNum;
		
		public GenderEnnum()
		{
		}
		
		public String getFirstName()
		{
			return firstName;
		}
		
		public void setFirstName(String firstName)
		{
			this.firstName= firstName;
		}
		
		public String getLastName()
		{
			return lastName;
		}
		
		public void setLastName(String lastName)
		{
			this.lastName= lastName;
		}
		
		public int getPhoneNum()
		{
			return phoneNum;
		}
		
		public void setPhoneNum(int phoneNum)
		{
			this.phoneNum= phoneNum;
		}
	}

