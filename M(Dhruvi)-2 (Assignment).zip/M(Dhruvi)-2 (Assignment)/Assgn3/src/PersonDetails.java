import java.time.LocalDate;

import java.time.Period;


/*3.7: Modify Lab assignment 2.3 to perform following functionalities:
a) Add a method called calculateAge which should accept person�s date of birth and 
   calculate age of a person.
b) Add a method called getFullName(String firstName, String lastName) which 
   should return full name of a person
   Display person details with age and fullname.*/

public class PersonDetails 
{
	 String firstName;
	 String lastName;
	 String gender;
	 LocalDate  Dob;
	
	public PersonDetails()
	{
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public void setFirstName(String firstName)
	{
		this.firstName= firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public void setLastName(String lastName)
	{
		this.lastName= lastName;
	}
	
	public String getGender()
	{
		return gender;
	}
	
	public void setGender(String gender)
	{
		this.gender= gender;
	}

	public void setDob(LocalDate Dob)
	
	{
		this.Dob= Dob;
	}
	public LocalDate getDob()
	{
		return Dob;
	}
	
	 public String getFullName(String firstName, String lastName)
	 {
		String fullname=  firstName +" "+ lastName;
		return fullname;
	 }
	 
	
	 public String getAge(LocalDate Dob)
	 { 
		 LocalDate today=LocalDate.now();
		 Period per=Period.between(Dob, today);
		 return (per.getYears()+" Years ,"+per.getMonths()+" Months ,"+per.getDays()
				 +" Days");
	 }
	 
	public void dispInfo()
	{
		System.out.println("your full name is : "+getFullName(firstName,lastName));
		
	}
}
