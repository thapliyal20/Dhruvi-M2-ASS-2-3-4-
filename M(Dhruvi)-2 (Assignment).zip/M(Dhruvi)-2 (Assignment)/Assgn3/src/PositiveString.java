
/*3.2: Create a method that accepts a String and checks if it is a positive string. 
A string is considered a positive string, if on moving from left to right each character
in the String comes after the previous characters in the Alphabetical order.
For Example: ANT is a positive String (Since T comes after N and N comes after A).
The method should return true if the entered string is positive.*/

import java.util.Scanner;

public class PositiveString 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the string : ");
		String str = sc.next();
		boolean boolean1=true;
			
		for(int i=1; i<str.length();i++)
		{
			if(boolean1== true){
			if(str.charAt(i)>str.charAt(i-1))
			{
				boolean1 = true;
			}
			else
			{
				boolean1= false;
			}
			}
			else
				boolean1= false;
			}
			if(boolean1 == true)
			{
				System.out.println("The string " +str + " is positive");
			}
			else
			{
				System.out.println("The string " +str + " is negative");
			}
		sc.close();
	}
}
