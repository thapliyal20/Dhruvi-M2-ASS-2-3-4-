import java.time.LocalDate;
import java.util.Scanner;

/*3.5: Create a method to accept product purchase date and warrantee period 
(in terms of months and years).
Print the date on which warrantee of product expires*/

public class GetExpiryDate {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);	
		System.out.print("Enter purchase day: ");
		int day = sc.nextInt();	
		System.out.print("Enter purchase month: ");
		int mon = sc.nextInt();	
		System.out.print("Enter purchase year: ");
		int year = sc.nextInt();
		
		LocalDate purDate =  LocalDate.of(year,mon,day);
		System.out.print("Enter the warrented months: ");
		int mon1 = sc.nextInt();
		
		System.out.print("Enter the warrented month: ");
		int year1 = sc.nextInt();
		System.out.println("the expiry date is : "+purDate.plusMonths((year1*12)+mon1));
		
		sc.close();
	}

}
