import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;



public class TestPersonDetails {
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		PersonDetails s1 = new PersonDetails();
		
		System.out.println("Enter first name");
		String frst = sc.next();
		System.out.println("Enter last name");
		String last= sc.next();
		System.out.println("Enter date of birth");
		String dob = sc.next();
		System.out.println("Enter gender");
		String gen= sc.next();
		 
		DateTimeFormatter myFormatter= DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	    LocalDate mydob=LocalDate.parse(dob,myFormatter);
		
	    s1.setLastName(frst);
		s1.setFirstName(last);
		s1.setGender(gen);
		
		s1.dispInfo();
		System.out.println(s1.getAge(mydob));
	
	sc.close();
}
}
