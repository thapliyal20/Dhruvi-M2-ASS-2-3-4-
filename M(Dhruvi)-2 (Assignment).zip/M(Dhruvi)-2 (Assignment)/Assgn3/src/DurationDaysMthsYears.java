/*3.4: Revise exercise 3.3 to accept two LocalDates and 
 * print the duration between dates in days, months and years.*/

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class DurationDaysMthsYears
{
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);	
	System.out.print("Enter day: ");
	int day = sc.nextInt();	
	System.out.print("Enter month: ");
	int mon = sc.nextInt();	
	System.out.print("Enter year: ");
	int year = sc.nextInt();
	
	System.out.print("Enter day: ");
	int day1 = sc.nextInt();	
	System.out.print("Enter month: ");
	int mon1 = sc.nextInt();	
	System.out.print("Enter year: ");
	int year1 = sc.nextInt();
	
	LocalDate date1 =  LocalDate.of(year,mon,day);
	LocalDate date2 =  LocalDate.of(year1,mon1,day1);
	Period per=Period.between(date1, date2);
	
	System.out.println("total days : "+per.getDays()+"\n   months: "+per.getMonths()
			 +"\n   years: "+per.getYears());
	sc.close();     
	}
}
