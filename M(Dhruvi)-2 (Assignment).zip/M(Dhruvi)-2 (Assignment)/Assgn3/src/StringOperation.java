/*3.1: Create a method which can perform a particular String operation based on the user�s choice. 
 * The method should accept the String object and the user�s choice and 
 * return the output of the operation.
  Options are
 1.Add the String to itself
 2.Replace odd positions with #
 3.Remove duplicate characters in the String
 4.Change odd characters to upper case*/

import java.util.Scanner; 

public class StringOperation
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the string : ");
		String str = sc.next();
		StringBuilder sb = new StringBuilder(str);
		System.out.println("\n1. Add string to itself.\n2. Replace odd positions with #.\n3. Remove duplicate characters.\n4. Change odd characters to upper case");
		int caseValue = sc.nextInt();
	
		switch(caseValue)
		{
		case 1:	 
			
			String str2 = str+str;
	        System.out.println("String after append : "+str2);
	        break;
		
		case 2:
			
			for (int i=1; i <str.length(); i++){
		        if (i % 2 == 0)
		        {
		          str = str.substring(0,i-1) + "#" + str.substring(i, str.length());
		        }
			}
			System.out.println("String after replace odd place char: "+str);
		break;
		case 3:
		
	        for (int i = 0; i < sb.length(); i++)
	        {
	            for (int j = i+1; j < sb.length(); j++) 
	            {
	                if (sb.charAt(i) == sb.charAt(j))
	                {
	                  sb.deleteCharAt(j);
	                }
	            }
	        }
	        System.out.println("String after remove: "+sb);
	        break;
	        
		case 4:
			
			for (int i=1; i <= str.length(); i++){
		        if (i % 2 == 0)
		        {
		          str = str.substring(0,i-1) + str.substring(i-1,i).toUpperCase() + str.substring(i, str.length());
		        }
			}
			System.out.println("String after replace: "+str);
			break;
		}
		sc.close();	
		}
	}

