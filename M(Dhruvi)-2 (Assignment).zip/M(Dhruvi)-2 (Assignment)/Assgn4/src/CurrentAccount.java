
public class CurrentAccount extends AccountDemo 
{
	final double minBalance =500;
	public CurrentAccount() 
	{
		super();
	}

	public CurrentAccount(long accNum, String perName, double balance)
	{
		super(accNum, perName, balance);
	}

	@Override
	public void withdraw(double withdrawAmt)
	{
		
		if( withdrawAmt<minBalance)
		{
			System.out.println("You have insufficient balance!");
		}
		else
        {
			double updatedBal=balance - withdrawAmt; 
			System.out.println("your updated balance is :"+ updatedBal+"\n");
		}
	}
	
}
