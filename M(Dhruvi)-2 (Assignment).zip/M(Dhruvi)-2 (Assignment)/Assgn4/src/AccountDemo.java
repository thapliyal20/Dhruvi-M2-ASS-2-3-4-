
public abstract class AccountDemo 
{
	long accNum;
	String perName;
	double balance;
	
	public AccountDemo()
	{ }
	
	public AccountDemo(long accNum, String perName,double balance)
	{
		this.accNum = accNum;
		this.perName = perName;
		this.balance= balance;
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public String getPerName() {
		return perName;
	}

	public void setPerName(String perName) {
		this.perName = perName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public abstract  void withdraw(double withdrawAmt);

	public String dispInfo() {
		return "Account number: " + accNum + "\nperson name : " + perName
				+ " \nbalance : " + balance+"\n" ;
	}
	
	
}
