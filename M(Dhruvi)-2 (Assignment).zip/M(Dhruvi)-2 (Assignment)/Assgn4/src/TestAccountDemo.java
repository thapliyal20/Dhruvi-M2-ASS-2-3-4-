import java.util.Scanner;

/*4.2: Extend the functionality through Inheritance and polymorphism (Maintenance)
Inherit two classes Savings Account and Current Account from account class. 
Implement the following in the respective classes.
a) Savings Account
a. Add a variable called minimum Balance and assign final modifier.
b. Override method called withdraw 
(This method should check for minimum balance and allow withdraw to happen)

b) Current Account
a. Add a variable called overdraft Limit
b. Override method called withdraw 
(checks whether overdraft limit is reached and returns a boolean value accordingly)*/

public  class TestAccountDemo 
{
	public static void main(String[] args) 
	{
		CurrentAccount dhruvi = new CurrentAccount(1234,"dhruvi",40000);
		SavingAccount darsh = new SavingAccount(12345,"darsh",1000);
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println(dhruvi.dispInfo());
		System.out.println("Enter withdraw amount: ");
		double withdraw=sc.nextInt();
		dhruvi.withdraw(withdraw);
		
		System.out.println(darsh.dispInfo());
		System.out.println("Enter amount for deposit: ");
		double overdraft =sc.nextInt();
		darsh.withdraw(overdraft);
		sc.close();
	}
}
